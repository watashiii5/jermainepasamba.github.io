

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Java_pointofsalesproject extends javax.swing.JFrame {
    public Java_pointofsalesproject(){
        initComponents();
        Connect();
        Connect1();
    }
    
    Connection con;
    PreparedStatement pst;
 public void Connect1()
{
    try{
    Class.forName("com.mysql.cj.jdbc.Driver");
    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/product","root","");
    System.out.println("Connect");
    }catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Product_List.class.getName()).log(Level.SEVERE, null, ex);
        }
}
 public void Connect(){
        try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/userlist","root","");
        System.out.println("HIEIRHIREHEIRHREIH");
        } catch (ClassNotFoundException | SQLException ex){
        Logger.getLogger(User_List.class.getName()).log(Level.SEVERE, null , ex);
    }
 }
public void addtable(String Item, int Qty, Double Price){
    
    DefaultTableModel dt = (DefaultTableModel) jTable1.getModel();
    
    DecimalFormat df = new DecimalFormat("00.00");
    double totPrice = Price * Double.valueOf(Qty);
    String TotalPrice = df.format(totPrice);
    
    
    for (int row = 0; row < jTable1.getRowCount(); row++){
        if(Item == jTable1.getValueAt(row,0)){
            dt.removeRow(jTable1.convertRowIndexToModel(row));
            }
        

    }
    Vector v = new Vector();
    v.add(Item);
    v.add(Qty);
    
    v.add(TotalPrice);
    dt.addRow(v);
          
}
public void cal(){

    int numOfRow = jTable1.getRowCount();
    double tot = 0.0;
    
        for(int i=0; i< numOfRow; i++){
            double value = Double.parseDouble(jTable1.getValueAt(i,2).toString());
            tot += value;
    }
    DecimalFormat df = new DecimalFormat("00.00");
    jTxttotal.setText(df.format(tot));
}

    /**
     *
     */
    @SuppressWarnings("unchecked")
   
   
    public void Itemcost()
   {
          double sum = 0;
          
          
          for (int i = 0 ; i < jTable1.getRowCount(); i++)
                  {
                      sum = sum + Double.parseDouble(jTable1.getValueAt(i, 2).toString());
                  }
          jTxtSubtotal.setText(Double.toString(sum));
          double cTotall = Double.parseDouble(jTxtSubtotal.getText());
          
          double cTax = (cTotall * 3.9)/100;
          String iTaxtotal = String.format("₱ %.2f",cTax);
          jtxttax.setText(iTaxtotal);
          
          String iSubTotal = String.format("₱ %.2f",cTotall);
          jTxtSubtotal.setText(iSubTotal);
          
          String itotal = String.format("₱ %.2f", cTotall + cTax);
          jTxttotal.setText(itotal);
                 
   }  
   //===============================function change============================================
    
   public void Change()
   {
    double sum = 0;
    // double tax = 3.9; //
    double cash = Double.parseDouble(jtxtdisplay.getText());
    
     for (int i = 0 ; i < jTable1.getRowCount(); i++)
                  {
                      sum = sum + Double.parseDouble(jTable1.getValueAt(i, 2).toString());
                  }
     double cTax = (sum * 3.9)/100;
     double cChange = (cash -(sum  + cTax));
     
     String ChangeGiven = String.format("₱ %.2f", cChange);
     jTxtChange.setText(ChangeGiven);
     
   }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        jPanel1 = new javax.swing.JPanel();
        jbtnpoint = new javax.swing.JButton();
        jbtn7 = new javax.swing.JButton();
        jbtn8 = new javax.swing.JButton();
        jbtn4 = new javax.swing.JButton();
        jbtn5 = new javax.swing.JButton();
        jbtn6 = new javax.swing.JButton();
        jbtn1 = new javax.swing.JButton();
        jbtn2 = new javax.swing.JButton();
        jbtn3 = new javax.swing.JButton();
        jbtn0 = new javax.swing.JButton();
        jbtnc = new javax.swing.JButton();
        jbtn9 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jbtnpoint1 = new javax.swing.JButton();
        jbtn10 = new javax.swing.JButton();
        jbtn11 = new javax.swing.JButton();
        jbtn12 = new javax.swing.JButton();
        jbtn13 = new javax.swing.JButton();
        jbtn14 = new javax.swing.JButton();
        jbtn15 = new javax.swing.JButton();
        jbtn16 = new javax.swing.JButton();
        jbtn17 = new javax.swing.JButton();
        jbtn18 = new javax.swing.JButton();
        jbtnc1 = new javax.swing.JButton();
        jbtn19 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jbtnpoint2 = new javax.swing.JButton();
        jbtn20 = new javax.swing.JButton();
        jbtn21 = new javax.swing.JButton();
        jbtn22 = new javax.swing.JButton();
        jbtn23 = new javax.swing.JButton();
        jbtn24 = new javax.swing.JButton();
        jbtn25 = new javax.swing.JButton();
        jbtn26 = new javax.swing.JButton();
        jbtn27 = new javax.swing.JButton();
        jbtn28 = new javax.swing.JButton();
        jbtnc2 = new javax.swing.JButton();
        jbtn29 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jbtnpoint3 = new javax.swing.JButton();
        jbtn30 = new javax.swing.JButton();
        jbtn31 = new javax.swing.JButton();
        jbtn32 = new javax.swing.JButton();
        jbtn33 = new javax.swing.JButton();
        jbtn34 = new javax.swing.JButton();
        jbtn35 = new javax.swing.JButton();
        jbtn36 = new javax.swing.JButton();
        jbtn37 = new javax.swing.JButton();
        jbtn38 = new javax.swing.JButton();
        jbtnc3 = new javax.swing.JButton();
        jbtn39 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jcbopayment = new javax.swing.JComboBox<>();
        jtxtdisplay = new javax.swing.JTextField();
        jTxtChange = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jbtnremove = new javax.swing.JButton();
        jBtnpay = new javax.swing.JButton();
        jbtnpay1 = new javax.swing.JButton();
        jbtnprint = new javax.swing.JButton();
        jbtnexit = new javax.swing.JButton();
        jbtnreset = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jTxttotal = new javax.swing.JTextField();
        jTxtSubtotal = new javax.swing.JTextField();
        jtxttax = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel8 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel10 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jBtnHamandEggSunriseCombo = new javax.swing.JButton();
        jBtnSunriseFiestaPlatter = new javax.swing.JButton();
        jBtnpancake = new javax.swing.JButton();
        jBtnsoftscrambleandsweetpotato = new javax.swing.JButton();
        jBtnhomemademcgriddle = new javax.swing.JButton();
        jBtnsweetcreamedcorn = new javax.swing.JButton();
        jBtnClassicBreakfastFusion1 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        q1 = new javax.swing.JLabel();
        q2 = new javax.swing.JLabel();
        q3 = new javax.swing.JLabel();
        q4 = new javax.swing.JLabel();
        q5 = new javax.swing.JLabel();
        q6 = new javax.swing.JLabel();
        q7 = new javax.swing.JLabel();
        q8 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jBtnSunnyDogScramble = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jBtncremebrule = new javax.swing.JButton();
        jBtnlavacake = new javax.swing.JButton();
        jBtncheesecake = new javax.swing.JButton();
        jBtnchurros = new javax.swing.JButton();
        jBtnchocolatebitssundae = new javax.swing.JButton();
        jBtnTiramisu = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        r1 = new javax.swing.JLabel();
        r2 = new javax.swing.JLabel();
        r3 = new javax.swing.JLabel();
        r4 = new javax.swing.JLabel();
        r5 = new javax.swing.JLabel();
        r6 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jBtnkeemasamosa = new javax.swing.JButton();
        jBtnmozzarellasticks = new javax.swing.JButton();
        jBtnquiche = new javax.swing.JButton();
        jBtncheezyfries = new javax.swing.JButton();
        jBtnpretzel = new javax.swing.JButton();
        jBtnjalapenopoppers = new javax.swing.JButton();
        jBtnbrushetta = new javax.swing.JButton();
        jBtngranolabars = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        s1 = new javax.swing.JLabel();
        s2 = new javax.swing.JLabel();
        s3 = new javax.swing.JLabel();
        s4 = new javax.swing.JLabel();
        s5 = new javax.swing.JLabel();
        s6 = new javax.swing.JLabel();
        s7 = new javax.swing.JLabel();
        s8 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jBtnCaramelFrap = new javax.swing.JButton();
        jBtnChocolateFrap = new javax.swing.JButton();
        jBtnwhippedcoffee = new javax.swing.JButton();
        jBtnblackcoffee = new javax.swing.JButton();
        jBtncappucino = new javax.swing.JButton();
        jBtnforzencaramelfrap = new javax.swing.JButton();
        jBtnicedlattecoffee = new javax.swing.JButton();
        jBtncoconutmocha = new javax.swing.JButton();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        t1 = new javax.swing.JLabel();
        t2 = new javax.swing.JLabel();
        t3 = new javax.swing.JLabel();
        t4 = new javax.swing.JLabel();
        t5 = new javax.swing.JLabel();
        t6 = new javax.swing.JLabel();
        t7 = new javax.swing.JLabel();
        t8 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jBtnSunnyDogScramble1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        b = new javax.swing.JTextArea();
        jbtnprint1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 204));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jbtnpoint.setBackground(new java.awt.Color(153, 153, 153));
        jbtnpoint.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtnpoint.setText(".");
        jbtnpoint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnpointActionPerformed(evt);
            }
        });
        jPanel1.add(jbtnpoint, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 60, 60));

        jbtn7.setBackground(new java.awt.Color(153, 153, 153));
        jbtn7.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn7.setText("7");
        jbtn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn7ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 60, 60));

        jbtn8.setBackground(new java.awt.Color(153, 153, 153));
        jbtn8.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn8.setText("8");
        jbtn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn8ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn8, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 60, 60));

        jbtn4.setBackground(new java.awt.Color(153, 153, 153));
        jbtn4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn4.setText("4");
        jbtn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn4ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 60, 60));

        jbtn5.setBackground(new java.awt.Color(153, 153, 153));
        jbtn5.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn5.setText("5");
        jbtn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn5ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn5, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 60, 60));

        jbtn6.setBackground(new java.awt.Color(153, 153, 153));
        jbtn6.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn6.setText("6");
        jbtn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn6ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn6, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 60, 60));

        jbtn1.setBackground(new java.awt.Color(153, 153, 153));
        jbtn1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn1.setText("1");
        jbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn1ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 60, 60));

        jbtn2.setBackground(new java.awt.Color(153, 153, 153));
        jbtn2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn2.setText("2");
        jbtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn2ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, 60, 60));

        jbtn3.setBackground(new java.awt.Color(153, 153, 153));
        jbtn3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn3.setText("3");
        jbtn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn3ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 60, 60));

        jbtn0.setBackground(new java.awt.Color(153, 153, 153));
        jbtn0.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn0.setText("0");
        jbtn0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn0ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn0, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, 60, 60));

        jbtnc.setBackground(new java.awt.Color(255, 102, 0));
        jbtnc.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtnc.setText("C");
        jbtnc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtncActionPerformed(evt);
            }
        });
        jPanel1.add(jbtnc, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, 60, 60));

        jbtn9.setBackground(new java.awt.Color(153, 153, 153));
        jbtn9.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn9.setText("9");
        jbtn9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn9ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn9, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 20, 60, 60));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jbtnpoint1.setBackground(new java.awt.Color(153, 153, 153));
        jbtnpoint1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtnpoint1.setText(".");
        jbtnpoint1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnpoint1ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnpoint1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 60, 60));

        jbtn10.setBackground(new java.awt.Color(153, 153, 153));
        jbtn10.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn10.setText("7");
        jbtn10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn10ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 60, 60));

        jbtn11.setBackground(new java.awt.Color(153, 153, 153));
        jbtn11.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn11.setText("8");
        jbtn11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn11ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn11, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 60, 60));

        jbtn12.setBackground(new java.awt.Color(153, 153, 153));
        jbtn12.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn12.setText("4");
        jbtn12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn12ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 60, 60));

        jbtn13.setBackground(new java.awt.Color(153, 153, 153));
        jbtn13.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn13.setText("5");
        jbtn13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn13ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn13, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 60, 60));

        jbtn14.setBackground(new java.awt.Color(153, 153, 153));
        jbtn14.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn14.setText("6");
        jbtn14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn14ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn14, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 60, 60));

        jbtn15.setBackground(new java.awt.Color(153, 153, 153));
        jbtn15.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn15.setText("1");
        jbtn15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn15ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 60, 60));

        jbtn16.setBackground(new java.awt.Color(153, 153, 153));
        jbtn16.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn16.setText("2");
        jbtn16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn16ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn16, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, 60, 60));

        jbtn17.setBackground(new java.awt.Color(153, 153, 153));
        jbtn17.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn17.setText("3");
        jbtn17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn17ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn17, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 60, 60));

        jbtn18.setBackground(new java.awt.Color(153, 153, 153));
        jbtn18.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn18.setText("0");
        jbtn18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn18ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn18, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, 60, 60));

        jbtnc1.setBackground(new java.awt.Color(204, 0, 0));
        jbtnc1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtnc1.setText("C");
        jbtnc1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnc1ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnc1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, 60, 60));

        jbtn19.setBackground(new java.awt.Color(153, 153, 153));
        jbtn19.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn19.setText("9");
        jbtn19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn19ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtn19, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 20, 60, 60));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 20, 240, 340));

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jbtnpoint2.setBackground(new java.awt.Color(153, 153, 153));
        jbtnpoint2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtnpoint2.setText(".");
        jbtnpoint2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnpoint2ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnpoint2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 60, 60));

        jbtn20.setBackground(new java.awt.Color(153, 153, 153));
        jbtn20.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn20.setText("7");
        jbtn20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn20ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtn20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 60, 60));

        jbtn21.setBackground(new java.awt.Color(153, 153, 153));
        jbtn21.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn21.setText("8");
        jbtn21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn21ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtn21, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 60, 60));

        jbtn22.setBackground(new java.awt.Color(153, 153, 153));
        jbtn22.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn22.setText("4");
        jbtn22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn22ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtn22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 60, 60));

        jbtn23.setBackground(new java.awt.Color(153, 153, 153));
        jbtn23.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn23.setText("5");
        jbtn23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn23ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtn23, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 60, 60));

        jbtn24.setBackground(new java.awt.Color(153, 153, 153));
        jbtn24.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn24.setText("6");
        jbtn24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn24ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtn24, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 60, 60));

        jbtn25.setBackground(new java.awt.Color(153, 153, 153));
        jbtn25.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn25.setText("1");
        jbtn25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn25ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtn25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 60, 60));

        jbtn26.setBackground(new java.awt.Color(153, 153, 153));
        jbtn26.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn26.setText("2");
        jbtn26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn26ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtn26, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, 60, 60));

        jbtn27.setBackground(new java.awt.Color(153, 153, 153));
        jbtn27.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn27.setText("3");
        jbtn27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn27ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtn27, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 60, 60));

        jbtn28.setBackground(new java.awt.Color(153, 153, 153));
        jbtn28.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn28.setText("0");
        jbtn28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn28ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtn28, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, 60, 60));

        jbtnc2.setBackground(new java.awt.Color(204, 0, 0));
        jbtnc2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtnc2.setText("C");
        jbtnc2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnc2ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnc2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, 60, 60));

        jbtn29.setBackground(new java.awt.Color(153, 153, 153));
        jbtn29.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn29.setText("9");
        jbtn29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn29ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtn29, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 20, 60, 60));

        jPanel7.setBackground(new java.awt.Color(204, 204, 204));
        jPanel7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jbtnpoint3.setBackground(new java.awt.Color(153, 153, 153));
        jbtnpoint3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtnpoint3.setText(".");
        jbtnpoint3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnpoint3ActionPerformed(evt);
            }
        });
        jPanel7.add(jbtnpoint3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 60, 60));

        jbtn30.setBackground(new java.awt.Color(153, 153, 153));
        jbtn30.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn30.setText("7");
        jbtn30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn30ActionPerformed(evt);
            }
        });
        jPanel7.add(jbtn30, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 60, 60));

        jbtn31.setBackground(new java.awt.Color(153, 153, 153));
        jbtn31.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn31.setText("8");
        jbtn31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn31ActionPerformed(evt);
            }
        });
        jPanel7.add(jbtn31, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 60, 60));

        jbtn32.setBackground(new java.awt.Color(153, 153, 153));
        jbtn32.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn32.setText("4");
        jbtn32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn32ActionPerformed(evt);
            }
        });
        jPanel7.add(jbtn32, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 60, 60));

        jbtn33.setBackground(new java.awt.Color(153, 153, 153));
        jbtn33.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn33.setText("5");
        jbtn33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn33ActionPerformed(evt);
            }
        });
        jPanel7.add(jbtn33, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 60, 60));

        jbtn34.setBackground(new java.awt.Color(153, 153, 153));
        jbtn34.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn34.setText("6");
        jbtn34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn34ActionPerformed(evt);
            }
        });
        jPanel7.add(jbtn34, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 60, 60));

        jbtn35.setBackground(new java.awt.Color(153, 153, 153));
        jbtn35.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn35.setText("1");
        jbtn35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn35ActionPerformed(evt);
            }
        });
        jPanel7.add(jbtn35, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 60, 60));

        jbtn36.setBackground(new java.awt.Color(153, 153, 153));
        jbtn36.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn36.setText("2");
        jbtn36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn36ActionPerformed(evt);
            }
        });
        jPanel7.add(jbtn36, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, 60, 60));

        jbtn37.setBackground(new java.awt.Color(153, 153, 153));
        jbtn37.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn37.setText("3");
        jbtn37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn37ActionPerformed(evt);
            }
        });
        jPanel7.add(jbtn37, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 60, 60));

        jbtn38.setBackground(new java.awt.Color(153, 153, 153));
        jbtn38.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn38.setText("0");
        jbtn38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn38ActionPerformed(evt);
            }
        });
        jPanel7.add(jbtn38, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, 60, 60));

        jbtnc3.setBackground(new java.awt.Color(204, 0, 0));
        jbtnc3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtnc3.setText("C");
        jbtnc3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnc3ActionPerformed(evt);
            }
        });
        jPanel7.add(jbtnc3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, 60, 60));

        jbtn39.setBackground(new java.awt.Color(153, 153, 153));
        jbtn39.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jbtn39.setText("9");
        jbtn39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn39ActionPerformed(evt);
            }
        });
        jPanel7.add(jbtn39, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 20, 60, 60));

        jPanel5.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 20, 240, 340));

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 20, 240, 340));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 470, 240, 340));

        jPanel3.setBackground(new java.awt.Color(204, 255, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 199, -1, -1));

        jPanel11.setBackground(new java.awt.Color(255, 255, 204));
        jPanel11.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Change");
        jPanel11.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 120, 40));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setText("Payment Method");
        jPanel11.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 200, 40));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setText("₱");
        jPanel11.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, 120, 40));

        jcbopayment.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jcbopayment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Cash", "Gcash", "Maya", "Visa Card", "Credit Card", "Master Card" }));
        jcbopayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbopaymentActionPerformed(evt);
            }
        });
        jPanel11.add(jcbopayment, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 12, 170, -1));

        jtxtdisplay.setBackground(new java.awt.Color(204, 255, 204));
        jtxtdisplay.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jtxtdisplay.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtxtdisplayMouseClicked(evt);
            }
        });
        jtxtdisplay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtdisplayActionPerformed(evt);
            }
        });
        jPanel11.add(jtxtdisplay, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 60, 190, 40));

        jTxtChange.setEditable(false);
        jTxtChange.setBackground(new java.awt.Color(204, 255, 204));
        jTxtChange.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jTxtChange.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTxtChangeMouseClicked(evt);
            }
        });
        jTxtChange.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxtChangeActionPerformed(evt);
            }
        });
        jPanel11.add(jTxtChange, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, 190, 40));

        jLabel44.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel44.setText("Cash");
        jPanel11.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 120, 40));

        jPanel3.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 390, 170));

        jPanel12.setBackground(new java.awt.Color(255, 255, 204));
        jPanel12.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jbtnremove.setBackground(new java.awt.Color(255, 204, 0));
        jbtnremove.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jbtnremove.setText("Remove");
        jbtnremove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnremoveActionPerformed(evt);
            }
        });
        jPanel12.add(jbtnremove, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 70, 140, 40));

        jBtnpay.setBackground(new java.awt.Color(255, 153, 0));
        jBtnpay.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jBtnpay.setText("Pay");
        jBtnpay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnpayActionPerformed(evt);
            }
        });
        jPanel12.add(jBtnpay, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 140, 40));

        jbtnpay1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jbtnpay1.setText("Pay");
        jbtnpay1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnpay1ActionPerformed(evt);
            }
        });
        jPanel12.add(jbtnpay1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 140, 40));

        jbtnprint.setBackground(new java.awt.Color(255, 204, 0));
        jbtnprint.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jbtnprint.setText("Print");
        jbtnprint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnprintActionPerformed(evt);
            }
        });
        jPanel12.add(jbtnprint, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 140, 40));

        jbtnexit.setBackground(new java.awt.Color(204, 255, 255));
        jbtnexit.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jbtnexit.setText("Exit");
        jbtnexit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnexitActionPerformed(evt);
            }
        });
        jPanel12.add(jbtnexit, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, 140, 40));

        jbtnreset.setBackground(new java.awt.Color(255, 153, 51));
        jbtnreset.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jbtnreset.setText("Reset");
        jbtnreset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnresetActionPerformed(evt);
            }
        });
        jPanel12.add(jbtnreset, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, 140, 40));

        jPanel3.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 20, 390, 170));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 610, 840, 220));

        jPanel6.setBackground(new java.awt.Color(204, 204, 204));
        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel6.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, -10, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setText("Total:");
        jPanel6.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 120, 40));

        jTxttotal.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jTxttotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxttotalActionPerformed(evt);
            }
        });
        jPanel6.add(jTxttotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 190, 40));

        jTxtSubtotal.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jTxtSubtotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxtSubtotalActionPerformed(evt);
            }
        });
        jPanel6.add(jTxtSubtotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 190, 40));

        jtxttax.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jtxttax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxttaxActionPerformed(evt);
            }
        });
        jPanel6.add(jtxttax, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 190, 40));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel7.setText("Subtotal:");
        jPanel6.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 120, 40));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setText("Tax:");
        jPanel6.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 120, 40));

        getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 490, 270, 290));

        jTable1.setBackground(new java.awt.Color(204, 204, 204));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item", "Qty", "Amount"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                true, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setToolTipText("");
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(200);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 0, 370, 460));
        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 380, -1, -1));

        jPanel8.setBackground(new java.awt.Color(204, 255, 204));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Gill Sans MT", 1, 60)); // NOI18N
        jLabel8.setText("  MENU");
        jPanel8.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 290, 40));

        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel12.setText("₱35");
        jPanel10.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 350, 50, -1));

        jBtnHamandEggSunriseCombo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Irish Weekend Fry-Up.jpg"))); // NOI18N
        jBtnHamandEggSunriseCombo.setText("jButton1");
        jBtnHamandEggSunriseCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnHamandEggSunriseComboActionPerformed(evt);
            }
        });
        jPanel10.add(jBtnHamandEggSunriseCombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 70, 120, 110));

        jBtnSunriseFiestaPlatter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Full English Breakfast.jpg"))); // NOI18N
        jBtnSunriseFiestaPlatter.setText("jButton1");
        jBtnSunriseFiestaPlatter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnSunriseFiestaPlatterActionPerformed(evt);
            }
        });
        jPanel10.add(jBtnSunriseFiestaPlatter, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 70, 120, 110));

        jBtnpancake.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/480f04b8-ba7e-488f-a0c4-8e439bd78fea.jpg"))); // NOI18N
        jBtnpancake.setText("jButton1");
        jBtnpancake.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnpancakeActionPerformed(evt);
            }
        });
        jPanel10.add(jBtnpancake, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 240, 120, 110));

        jBtnsoftscrambleandsweetpotato.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Soft Scramble and Roasted Sweet Potato Plate Recipe _ The Feedfeed.jpg"))); // NOI18N
        jBtnsoftscrambleandsweetpotato.setText("jButton1");
        jBtnsoftscrambleandsweetpotato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnsoftscrambleandsweetpotatoActionPerformed(evt);
            }
        });
        jPanel10.add(jBtnsoftscrambleandsweetpotato, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 240, 120, 110));

        jBtnhomemademcgriddle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Homemade Mcgriddle Recipe (30 Minute Breakfast!) - 730 Sage Street.jpg"))); // NOI18N
        jBtnhomemademcgriddle.setText("jButton1");
        jBtnhomemademcgriddle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnhomemademcgriddleActionPerformed(evt);
            }
        });
        jPanel10.add(jBtnhomemademcgriddle, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 240, 120, 110));

        jBtnsweetcreamedcorn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Sweet creamed corn with buttermilk pancakes and bacon recipe.jpg"))); // NOI18N
        jBtnsweetcreamedcorn.setText("jButton1");
        jBtnsweetcreamedcorn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnsweetcreamedcornActionPerformed(evt);
            }
        });
        jPanel10.add(jBtnsweetcreamedcorn, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 240, 120, 110));

        jBtnClassicBreakfastFusion1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Best Supermarket Products for a Country Breakfast.jpg"))); // NOI18N
        jBtnClassicBreakfastFusion1.setText("jButton1");
        jBtnClassicBreakfastFusion1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnClassicBreakfastFusion1ActionPerformed(evt);
            }
        });
        jPanel10.add(jBtnClassicBreakfastFusion1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 70, 120, 110));

        jLabel14.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel14.setText("Pancake");
        jPanel10.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 220, 60, 20));

        jLabel15.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel15.setText("₱95");
        jPanel10.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 180, 50, -1));

        jLabel16.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel16.setText("₱95");
        jPanel10.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 180, 50, -1));

        jLabel17.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel17.setText("₱99");
        jPanel10.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 180, 50, -1));

        jLabel18.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel18.setText("₱105");
        jPanel10.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 180, 60, -1));

        jLabel19.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel19.setText("₱65");
        jPanel10.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 350, 50, -1));

        jLabel20.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel20.setText("₱45");
        jPanel10.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 350, 50, -1));

        jLabel21.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel21.setText("₱40");
        jPanel10.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 350, 50, -1));

        q1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        q1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q1.setText("0");
        jPanel10.add(q1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, 30, -1));

        q2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        q2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q2.setText("0");
        jPanel10.add(q2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, 30, -1));

        q3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        q3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q3.setText("0");
        jPanel10.add(q3, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 120, 30, -1));

        q4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        q4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q4.setText("0");
        jPanel10.add(q4, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 120, 30, -1));

        q5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        q5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q5.setText("0");
        jPanel10.add(q5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 30, -1));

        q6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        q6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q6.setText("0");
        jPanel10.add(q6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 280, 30, -1));

        q7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        q7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q7.setText("0");
        jPanel10.add(q7, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 280, 30, -1));

        q8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        q8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q8.setText("0");
        jPanel10.add(q8, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 280, 30, -1));

        jLabel45.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel45.setText(" BREAKFAST");
        jPanel10.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 10, 160, 30));

        jLabel46.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel46.setText("Sunny Dog Scramble");
        jPanel10.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 50, 140, 20));

        jLabel47.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel47.setText("Sunrise Fiesta Platter");
        jPanel10.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 50, 140, 20));

        jLabel48.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel48.setText("Classic Breakfast Fusion");
        jPanel10.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 160, 20));

        jLabel49.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel49.setText("Hamand EggSunrise Combo");
        jPanel10.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 50, 190, 20));

        jLabel50.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel50.setText("Softs Cramble & SweetPotato");
        jPanel10.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 200, 20));

        jLabel51.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel51.setText("Homemade Mc Griddle");
        jPanel10.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 220, 170, 20));

        jLabel52.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel52.setText("Sweet Creamed Corn");
        jPanel10.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 220, 150, 20));

        jBtnSunnyDogScramble.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/7be08ee3-15c5-4428-93a4-7f5a631dccde.jpg"))); // NOI18N
        jBtnSunnyDogScramble.setText("jButton1");
        jBtnSunnyDogScramble.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnSunnyDogScrambleActionPerformed(evt);
            }
        });
        jPanel10.add(jBtnSunnyDogScramble, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 70, 120, 110));

        jTabbedPane2.addTab("BREAKFAST", jPanel10);

        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel13.setText("DESSERTS");
        jPanel9.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 0, 130, 30));

        jBtncremebrule.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Easy Creme Brulee.jpg"))); // NOI18N
        jBtncremebrule.setText("jButton9");
        jBtncremebrule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtncremebruleActionPerformed(evt);
            }
        });
        jPanel9.add(jBtncremebrule, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 50, 160, 120));

        jBtnlavacake.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Easy Chocolate Molten Lava Cakes.jpg"))); // NOI18N
        jBtnlavacake.setText("jButton9");
        jBtnlavacake.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnlavacakeActionPerformed(evt);
            }
        });
        jPanel9.add(jBtnlavacake, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 150, 120));

        jBtncheesecake.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Classic New York Cheesecake.jpg"))); // NOI18N
        jBtncheesecake.setText("jButton9");
        jBtncheesecake.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtncheesecakeActionPerformed(evt);
            }
        });
        jPanel9.add(jBtncheesecake, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 50, 160, 120));

        jBtnchurros.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Churros Recipe.jpg"))); // NOI18N
        jBtnchurros.setText("jButton9");
        jBtnchurros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnchurrosActionPerformed(evt);
            }
        });
        jPanel9.add(jBtnchurros, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 220, 160, 120));

        jBtnchocolatebitssundae.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Hot Fudge and Salted Chocolate Bits Sundae Recipe.jpg"))); // NOI18N
        jBtnchocolatebitssundae.setText("jButton9");
        jBtnchocolatebitssundae.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnchocolatebitssundaeActionPerformed(evt);
            }
        });
        jPanel9.add(jBtnchocolatebitssundae, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 220, 160, 120));

        jBtnTiramisu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Tiramisu ohne Ei & Alkohol - so geht_s » Provinzkoch.jpg"))); // NOI18N
        jBtnTiramisu.setText("jButton9");
        jBtnTiramisu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnTiramisuActionPerformed(evt);
            }
        });
        jPanel9.add(jBtnTiramisu, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 220, 160, 120));

        jLabel38.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel38.setText("₱45");
        jPanel9.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 340, 50, -1));

        jLabel39.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel39.setText("₱85");
        jPanel9.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 170, 50, -1));

        jLabel40.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel40.setText("₱80");
        jPanel9.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 170, 50, -1));

        jLabel41.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel41.setText("₱65");
        jPanel9.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 170, 50, -1));

        jLabel42.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel42.setText("₱55");
        jPanel9.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 340, 50, -1));

        jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel43.setText("₱75");
        jPanel9.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 340, 50, -1));

        r1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        r1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        r1.setText("0");
        jPanel9.add(r1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 30, -1));

        r2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        r2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        r2.setText("0");
        jPanel9.add(r2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 100, 30, -1));

        r3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        r3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        r3.setText("0");
        jPanel9.add(r3, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 100, 30, -1));

        r4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        r4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        r4.setText("0");
        jPanel9.add(r4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, 30, -1));

        r5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        r5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        r5.setText("0");
        jPanel9.add(r5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 260, 30, -1));

        r6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        r6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        r6.setText("0");
        jPanel9.add(r6, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 270, 30, -1));

        jLabel53.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel53.setText("Lava Cake");
        jPanel9.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 30, 80, 20));

        jLabel54.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel54.setText("Chocolatebit Sundae");
        jPanel9.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 140, 20));

        jLabel55.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel55.setText("Cheese Cake");
        jPanel9.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 30, 90, 20));

        jLabel56.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel56.setText("Creme Brule");
        jPanel9.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 30, 140, 20));

        jLabel57.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel57.setText("Churros");
        jPanel9.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 200, 60, 20));

        jLabel58.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel58.setText("Tiramisu");
        jPanel9.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 200, 60, 20));

        jTabbedPane2.addTab("DESSERTS", jPanel9);

        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel11.setText("SNACKS");
        jPanel14.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 10, 100, 30));

        jBtnkeemasamosa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Best Keema Samosa Recipe (Patti Samosa) - Cubes N Juliennes.jpg"))); // NOI18N
        jBtnkeemasamosa.setText("jButton1");
        jBtnkeemasamosa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnkeemasamosaActionPerformed(evt);
            }
        });
        jPanel14.add(jBtnkeemasamosa, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 60, 120, 110));

        jBtnmozzarellasticks.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Air Fryer Mozzarella Sticks.jpg"))); // NOI18N
        jBtnmozzarellasticks.setText("jButton1");
        jBtnmozzarellasticks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnmozzarellasticksActionPerformed(evt);
            }
        });
        jPanel14.add(jBtnmozzarellasticks, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 120, 110));

        jBtnquiche.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/How to Make Ham and Cheese Quiche In the Slow Cooker.jpg"))); // NOI18N
        jBtnquiche.setText("jButton1");
        jBtnquiche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnquicheActionPerformed(evt);
            }
        });
        jPanel14.add(jBtnquiche, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 60, 120, 110));

        jBtncheezyfries.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Cheese Fries The Ultimate Comfort Food.jpg"))); // NOI18N
        jBtncheezyfries.setText("jButton1");
        jBtncheezyfries.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtncheezyfriesActionPerformed(evt);
            }
        });
        jPanel14.add(jBtncheezyfries, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 60, 120, 110));

        jBtnpretzel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Laugenbrezeln (German Lye Pretzels).jpg"))); // NOI18N
        jBtnpretzel.setText("jButton1");
        jBtnpretzel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnpretzelActionPerformed(evt);
            }
        });
        jPanel14.add(jBtnpretzel, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 230, 120, 110));

        jBtnjalapenopoppers.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/The BEST Jalapeño Poppers _ The Modern Proper.jpg"))); // NOI18N
        jBtnjalapenopoppers.setText("jButton1");
        jBtnjalapenopoppers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnjalapenopoppersActionPerformed(evt);
            }
        });
        jPanel14.add(jBtnjalapenopoppers, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 230, 120, 110));

        jBtnbrushetta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Bruschetta.jpg"))); // NOI18N
        jBtnbrushetta.setText("jButton1");
        jBtnbrushetta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnbrushettaActionPerformed(evt);
            }
        });
        jPanel14.add(jBtnbrushetta, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 230, 120, 110));

        jBtngranolabars.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/No-Bake Chewy Granola Bars Recipe.jpg"))); // NOI18N
        jBtngranolabars.setText("jButton1");
        jBtngranolabars.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtngranolabarsActionPerformed(evt);
            }
        });
        jPanel14.add(jBtngranolabars, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 230, 120, 110));

        jLabel22.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel22.setText("₱55");
        jPanel14.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 340, 50, -1));

        jLabel23.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel23.setText("₱55");
        jPanel14.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 170, 50, -1));

        jLabel24.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel24.setText("₱48");
        jPanel14.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 170, 50, -1));

        jLabel25.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel25.setText("₱60");
        jPanel14.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 170, 50, -1));

        jLabel26.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel26.setText("₱50");
        jPanel14.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 170, 50, -1));

        jLabel27.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel27.setText("₱60");
        jPanel14.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 340, 50, -1));

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel28.setText("₱35");
        jPanel14.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 340, 50, -1));

        jLabel29.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel29.setText("₱48");
        jPanel14.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 340, 50, -1));

        s1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        s1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        s1.setText("0");
        jPanel14.add(s1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, 30, -1));

        s2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        s2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        s2.setText("0");
        jPanel14.add(s2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 110, 30, -1));

        s3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        s3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        s3.setText("0");
        jPanel14.add(s3, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 110, 30, -1));

        s4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        s4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        s4.setText("0");
        jPanel14.add(s4, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 110, 30, -1));

        s5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        s5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        s5.setText("0");
        jPanel14.add(s5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 270, 30, -1));

        s6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        s6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        s6.setText("0");
        jPanel14.add(s6, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 270, 30, -1));

        s7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        s7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        s7.setText("0");
        jPanel14.add(s7, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 270, 30, -1));

        s8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        s8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        s8.setText("0");
        jPanel14.add(s8, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 270, 30, -1));

        jLabel59.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel59.setText("Jalapeno Poppers");
        jPanel14.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 210, 140, 20));

        jLabel60.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel60.setText("Mozzarella Sticks");
        jPanel14.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 40, 140, 20));

        jLabel61.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel61.setText("Keemasamosa");
        jPanel14.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 40, 110, 20));

        jLabel62.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel62.setText("Cheezy Fries");
        jPanel14.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 40, 100, 20));

        jLabel63.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel63.setText("Quiche");
        jPanel14.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 40, 60, 20));

        jLabel65.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel65.setText("Brushetta");
        jPanel14.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 210, 80, 20));

        jLabel66.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel66.setText("Pretzel");
        jPanel14.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 210, 80, 20));

        jLabel68.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel68.setText("Granola Bars");
        jPanel14.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 210, 90, 20));

        jTabbedPane2.addTab("SNACKS", jPanel14);

        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel9.setText("COFFEE");
        jPanel15.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 10, 100, 40));

        jBtnCaramelFrap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/FRAPCRE_CaramelCreamFrappuccino.jpg"))); // NOI18N
        jBtnCaramelFrap.setText("jButton1");
        jBtnCaramelFrap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnCaramelFrapActionPerformed(evt);
            }
        });
        jPanel15.add(jBtnCaramelFrap, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 60, 120, 110));

        jBtnChocolateFrap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/FRAPCRE_ChocolateCreamFrappuccino.jpg"))); // NOI18N
        jBtnChocolateFrap.setText("jButton1");
        jBtnChocolateFrap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnChocolateFrapActionPerformed(evt);
            }
        });
        jPanel15.add(jBtnChocolateFrap, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, 120, 110));

        jBtnwhippedcoffee.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Frothy Whipped Coffee White Russian_.jpg"))); // NOI18N
        jBtnwhippedcoffee.setText("jButton1");
        jBtnwhippedcoffee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnwhippedcoffeeActionPerformed(evt);
            }
        });
        jPanel15.add(jBtnwhippedcoffee, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 60, 110, 110));

        jBtnblackcoffee.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/English Coffee with Roasted Figs.jpg"))); // NOI18N
        jBtnblackcoffee.setText("jButton1");
        jBtnblackcoffee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnblackcoffeeActionPerformed(evt);
            }
        });
        jPanel15.add(jBtnblackcoffee, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 60, 120, 110));

        jBtncappucino.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Holiday Spiced Café Au Lait - The Local Palate.jpg"))); // NOI18N
        jBtncappucino.setText("jButton1");
        jBtncappucino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtncappucinoActionPerformed(evt);
            }
        });
        jPanel15.add(jBtncappucino, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 230, 120, 110));

        jBtnforzencaramelfrap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Frozen Coconut Caramel Frappe Recipe (with Cold Brew Concentrate) (1).jpg"))); // NOI18N
        jBtnforzencaramelfrap.setText("jButton1");
        jBtnforzencaramelfrap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnforzencaramelfrapActionPerformed(evt);
            }
        });
        jPanel15.add(jBtnforzencaramelfrap, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 230, 120, 110));

        jBtnicedlattecoffee.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Premium Photo _ Iced latte coffee cup on table in cafe coffee shop.jpg"))); // NOI18N
        jBtnicedlattecoffee.setText("jButton1");
        jBtnicedlattecoffee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnicedlattecoffeeActionPerformed(evt);
            }
        });
        jPanel15.add(jBtnicedlattecoffee, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 230, 120, 110));

        jBtncoconutmocha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Toasted Coconut Mocha.jpg"))); // NOI18N
        jBtncoconutmocha.setText("jButton1");
        jBtncoconutmocha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtncoconutmochaActionPerformed(evt);
            }
        });
        jPanel15.add(jBtncoconutmocha, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 230, 120, 110));

        jLabel30.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel30.setText("₱75");
        jPanel15.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 340, 50, -1));

        jLabel31.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel31.setText("₱60");
        jPanel15.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 50, -1));

        jLabel32.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel32.setText("₱60");
        jPanel15.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 170, 50, -1));

        jLabel33.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel33.setText("₱35");
        jPanel15.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 170, 50, -1));

        jLabel34.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel34.setText("₱65");
        jPanel15.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 170, 50, -1));

        jLabel35.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel35.setText("₱75");
        jPanel15.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 340, 50, -1));

        jLabel36.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel36.setText("₱55");
        jPanel15.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 340, 50, -1));

        jLabel37.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel37.setText("₱60");
        jPanel15.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 340, 50, -1));

        t1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        t1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t1.setText("0");
        jPanel15.add(t1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 30, -1));

        t2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        t2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t2.setText("0");
        jPanel15.add(t2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 110, 30, -1));

        t3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        t3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t3.setText("0");
        jPanel15.add(t3, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 110, 30, -1));

        t4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        t4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t4.setText("0");
        jPanel15.add(t4, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 110, 30, -1));

        t5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        t5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t5.setText("0");
        jPanel15.add(t5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 30, -1));

        t6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        t6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t6.setText("0");
        jPanel15.add(t6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 280, 30, -1));

        t7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        t7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t7.setText("0");
        jPanel15.add(t7, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 280, 30, -1));

        t8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        t8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        t8.setText("0");
        jPanel15.add(t8, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 280, 30, -1));

        jLabel67.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel67.setText("Chocolate Frap");
        jPanel15.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 40, 110, 20));

        jLabel69.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel69.setText("Carame Frap");
        jPanel15.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 40, 90, 20));

        jLabel70.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel70.setText("Black Coffee");
        jPanel15.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 40, 90, 20));

        jLabel71.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel71.setText("Whipped Coffee");
        jPanel15.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 40, 110, 20));

        jLabel72.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel72.setText("Iced Latte Coffee");
        jPanel15.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 210, 120, 20));

        jLabel73.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel73.setText(" Coconut Mocha ");
        jPanel15.add(jLabel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 210, 130, 20));

        jLabel74.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel74.setText("Cappucino");
        jPanel15.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 210, 80, 20));

        jLabel75.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        jLabel75.setText("Forzen Caramel Frap");
        jPanel15.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, 140, 20));

        jTabbedPane2.addTab("COFFEE", jPanel15);

        jPanel8.add(jTabbedPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 810, 420));

        jBtnSunnyDogScramble1.setBackground(new java.awt.Color(204, 255, 204));
        jBtnSunnyDogScramble1.setForeground(new java.awt.Color(204, 255, 204));
        jBtnSunnyDogScramble1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/LOGS.png"))); // NOI18N
        jBtnSunnyDogScramble1.setAlignmentY(0.0F);
        jBtnSunnyDogScramble1.setBorder(null);
        jBtnSunnyDogScramble1.setBorderPainted(false);
        jBtnSunnyDogScramble1.setContentAreaFilled(false);
        jBtnSunnyDogScramble1.setDefaultCapable(false);
        jBtnSunnyDogScramble1.setFocusable(false);
        jBtnSunnyDogScramble1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBtnSunnyDogScramble1.setIconTextGap(0);
        jBtnSunnyDogScramble1.setMargin(new java.awt.Insets(1, 1, 1, 1));
        jBtnSunnyDogScramble1.setMaximumSize(new java.awt.Dimension(1, 1));
        jBtnSunnyDogScramble1.setMinimumSize(new java.awt.Dimension(1, 1));
        jBtnSunnyDogScramble1.setName(""); // NOI18N
        jBtnSunnyDogScramble1.setOpaque(true);
        jBtnSunnyDogScramble1.setPreferredSize(new java.awt.Dimension(1, 1));
        jBtnSunnyDogScramble1.setSelected(true);
        jBtnSunnyDogScramble1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jBtnSunnyDogScramble1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnSunnyDogScramble1ActionPerformed(evt);
            }
        });
        jPanel8.add(jBtnSunnyDogScramble1, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 0, 230, 170));
        jBtnSunnyDogScramble1.getAccessibleContext().setAccessibleDescription("");

        getContentPane().add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 840, 590));

        b.setColumns(20);
        b.setRows(5);
        b.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                bAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane2.setViewportView(b);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1230, 0, 340, 460));

        jbtnprint1.setBackground(new java.awt.Color(204, 204, 204));
        jbtnprint1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jbtnprint1.setForeground(new java.awt.Color(51, 51, 51));
        jbtnprint1.setText("Print");
        jbtnprint1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnprint1ActionPerformed(evt);
            }
        });
        getContentPane().add(jbtnprint1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1470, 460, 80, 20));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnpointActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnpointActionPerformed
         String Enternumber = jtxtdisplay.getText();
        
        if ("".equals(Enternumber))
        {
            jtxtdisplay.setText(jbtnpoint.getText());
        }
        else 
        {
            Enternumber = jtxtdisplay.getText() + jbtnpoint.getText();
            jtxtdisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtnpointActionPerformed

    private void jbtn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn7ActionPerformed
         String Enternumber = jtxtdisplay.getText();
        
        if ("".equals(Enternumber))
        {
            jtxtdisplay.setText(jbtn7.getText());
        }
        else 
        {
            Enternumber = jtxtdisplay.getText() + jbtn7.getText();
            jtxtdisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn7ActionPerformed

    private void jbtn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn8ActionPerformed
         String Enternumber = jtxtdisplay.getText();
        
        if ("".equals(Enternumber))
        {
            jtxtdisplay.setText(jbtn8.getText());
        }
        else 
        {
            Enternumber = jtxtdisplay.getText() + jbtn8.getText();
            jtxtdisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn8ActionPerformed

    private void jbtn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn4ActionPerformed
        String Enternumber = jtxtdisplay.getText();
        
        if ("".equals(Enternumber))
        {
            jtxtdisplay.setText(jbtn4.getText());
        }
        else 
        {
            Enternumber = jtxtdisplay.getText() + jbtn4.getText();
            jtxtdisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn4ActionPerformed

    private void jbtn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn5ActionPerformed
        String Enternumber = jtxtdisplay.getText();
        
        if ("".equals(Enternumber))
        {
            jtxtdisplay.setText(jbtn5.getText());
        }
        else 
        {
            Enternumber = jtxtdisplay.getText() + jbtn5.getText();
            jtxtdisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn5ActionPerformed

    private void jbtn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn6ActionPerformed
        String Enternumber = jtxtdisplay.getText();
        
        if ("".equals(Enternumber))
        {
            jtxtdisplay.setText(jbtn6.getText());
        }
        else 
        {
            Enternumber = jtxtdisplay.getText() + jbtn6.getText();
            jtxtdisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn6ActionPerformed

    private void jbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn1ActionPerformed
         String Enternumber = jtxtdisplay.getText();
        
        if ("".equals(Enternumber))
        {
            jtxtdisplay.setText(jbtn1.getText());
        }
        else 
        {
            Enternumber = jtxtdisplay.getText() + jbtn1.getText();
            jtxtdisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn1ActionPerformed

    private void jbtn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn2ActionPerformed
         String Enternumber = jtxtdisplay.getText();
        
        if ("".equals(Enternumber))
        {
            jtxtdisplay.setText(jbtn2.getText());
        }
        else 
        {
            Enternumber = jtxtdisplay.getText() + jbtn2.getText();
            jtxtdisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn2ActionPerformed

    private void jbtn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn3ActionPerformed
         String Enternumber = jtxtdisplay.getText();
        
        if ("".equals(Enternumber))
        {
            jtxtdisplay.setText(jbtn3.getText());
        }
        else 
        {
            Enternumber = jtxtdisplay.getText() + jbtn3.getText();
            jtxtdisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn3ActionPerformed

    private void jtxttaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxttaxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxttaxActionPerformed

    private void jTxttotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxttotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTxttotalActionPerformed

    private void jbtn0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn0ActionPerformed
         String Enternumber = jtxtdisplay.getText();
        
        if ("".equals(Enternumber))
        {
            jtxtdisplay.setText(jbtn0.getText());
        }
        else 
        {
            Enternumber = jtxtdisplay.getText() + jbtn0.getText();
            jtxtdisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn0ActionPerformed

    private void jbtncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtncActionPerformed
        jtxtdisplay.setText("");
        jtxtdisplay.setText("");
       
    }//GEN-LAST:event_jbtncActionPerformed
    
    private void jbtnremoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnremoveActionPerformed
          
          
        DefaultTableModel Model = (DefaultTableModel) jTable1.getModel();
        String r = Model.getValueAt(jTable1.getSelectedRow(),0).toString();
        System.out.println(r);
        switch(r){
              case "Sunny Dog Scramble" -> q1.setText("0");
              case "Sunrise Fiesta Platter" -> q2.setText("0");
              case "Classic Breakfast Fusion" -> q3.setText("0");
              case "Hamand Egg Sunrise" -> q4.setText("0");
              case "Soft Scramble & Sweet Potato" -> q5.setText("0");
              case "Homemade MC Griddle" -> q6.setText("0");
              case "Sweet Creamed Corn" -> q7.setText("0");
              case "Pancake                " -> q8.setText("0");
              case "Lava Cake            " -> r1.setText("0");
              case "Cheese Cake            " -> r2.setText("0");
              case "Creme Brule            " -> r3.setText("0");
              case "Chocolate Bits Sundae" -> r4.setText("0");
              case "Tiramisu                      " -> r5.setText("0");
              case "Churros                " -> r6.setText("0");
              case "Mozzarella Sticks" -> s1.setText("0");
              case "Keemasamos        " -> s2.setText("0");
              case "Cheezy Fries        " -> s3.setText("0");
              case "Quiche                        " -> s4.setText("0");
              case "Jalepeno Poppers    " -> s5.setText("0");
              case "Pretzel                        " -> s6.setText("0");
              case "Granola Bars        " -> s7.setText("0");
              case "Brushetta            " -> s8.setText("0");
              case "Chocolate Frap    " -> t1.setText("0");
              case "Caramel Frap        " -> t2.setText("0");
              case "Black Coffee        " -> t3.setText("0");
              case "Whipped Coffee    " -> t4.setText("0");
              case "Frozen Caramel Frap" -> t5.setText("0");
              case "Cappucino            " -> t6.setText("0");
              case "Coconut Mocha    " -> t7.setText("0");
              case "Iced Latte Coffee" -> t8.setText("0");
              
              
              
              
              
          }
        
        int removeItem = jTable1.getSelectedRow();
        if(removeItem >= 0)
        {
            Model.removeRow(removeItem);
            
          }

        Itemcost();
        
          if(jcbopayment.getSelectedItem().equals("Cash"))
        {
            Change();
        }
        else
        {
            jtxtdisplay.setText("");
            jtxtdisplay.setText("");
        }
    }//GEN-LAST:event_jbtnremoveActionPerformed

    private void jbtnpay1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnpay1ActionPerformed
        // TODO add your handling code here:
          
          if(jcbopayment.getSelectedItem().equals("Cash"))
        {
            Change();
        }
        else
        {
            jtxtdisplay.setText("");
            jtxtdisplay.setText("");
        }
          
          
    }//GEN-LAST:event_jbtnpay1ActionPerformed

    private void jbtnprintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnprintActionPerformed
        // bill print
       
b.setText("");
        String PrinT=jbtnprint.getText();
        String ChE= jTxtChange.getText();

        if(ChE.isEmpty()){
            b.setText("");
            JOptionPane.showMessageDialog(rootPane, "Please pay first!?", "Error", 1);
        }else{
         try { 
            b.setText(b.getText()+"-------------------------------------------------------------------------------\n");
            b.setText(b.getText()+"-------------------------------------------------------------------------------\n");
            b.setText(b.getText()+"\t           Cravers Cafe\n");
            b.setText(b.getText()+"\t            Bulacan\n");
            b.setText(b.getText()+"\t           Philippines\n");
            b.setText(b.getText()+"-------------------------------------------------------------------------------\n");
            b.setText(b.getText()+"-------------------------------------------------------------------------------\n");
            b.setText(b.getText()+"Item \t\tQty \tPrice\n");
           DefaultTableModel df = (DefaultTableModel) jTable1.getModel();
           
           for(int i = 0; i < jTable1.getRowCount(); i++){
            String Item = df.getValueAt(i,0).toString();
            String Qty = df.getValueAt(i,1).toString();
            String Price = df.getValueAt(i,2).toString();
            
            b.setText(b.getText()+ Item + "\t" + Qty + "\t" + Price +"\n");
           }
    
      
             b.setText(b.getText()+"-------------------------------------------------------------------------------\n");
             
             b.setText(b.getText()+"------------------------------------------------------------------------------\n");
             b.setText(b.getText()+"Sub Total:\t\t\t "+ jTxtSubtotal.getText()+ "\n");
             b.setText(b.getText()+"Total:\t\t\t" + jTxttotal.getText()+"\n");
             b.setText(b.getText()+"Tax:\t\t\t" + jtxttax.getText()+"\n");
             b.setText(b.getText()+"Cash:\t\t\t" +"₱ "+ jtxtdisplay.getText()+"\n");
             b.setText(b.getText()+"Change:\t\t\t"+ jTxtChange.getText()+"\n");
             b.setText(b.getText()+"-------------------------------------------------------------------------------\n");
             b.setText(b.getText()+"-------------------------------------------------------------------------------\n");

        } catch(Exception e){} 
            
                
        }     
    }//GEN-LAST:event_jbtnprintActionPerformed
    
    
    private void jbtnexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnexitActionPerformed
        // TODO add your handling code here:
        int confirmed = JOptionPane.showConfirmDialog(null, "Exit Program?","EXIT",JOptionPane.YES_NO_OPTION);
        if(confirmed == JOptionPane.YES_OPTION){
        Login Log=new Login();
        Log.setVisible(true);
        dispose();}
    }//GEN-LAST:event_jbtnexitActionPerformed

    private void jbtnresetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnresetActionPerformed
        DefaultTableModel mode1 = (DefaultTableModel) jTable1.getModel();
        mode1.setRowCount(0);
        b.setText("");
        jtxtdisplay.setText("");
        jtxttax.setText("");
        jTxttotal.setText("");
        jTxtSubtotal.setText("");
        jTxtChange.setText("");
        q1.setText("0");
        q2.setText("0");
        q3.setText("0");
        q4.setText("0");
        q5.setText("0");
        q6.setText("0");
        q7.setText("0");
        q8.setText("0");
        r1.setText("0");
        r2.setText("0");
        r3.setText("0");
        r4.setText("0");
        r5.setText("0");
        r6.setText("0");
        s1.setText("0");
        s2.setText("0");
        s3.setText("0");
        s4.setText("0");
        s5.setText("0");
        s6.setText("0");
        s7.setText("0");
        s8.setText("0");
        t1.setText("0");
        t2.setText("0");
        t3.setText("0");
        t4.setText("0");
        t5.setText("0");
        t6.setText("0");
        t7.setText("0");
        t8.setText("0");        
    }//GEN-LAST:event_jbtnresetActionPerformed

    private void jbtn9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn9ActionPerformed
        String Enternumber = jtxtdisplay.getText();
        
        if ("".equals(Enternumber))
        {
            jtxtdisplay.setText(jbtn9.getText());
        }
        else 
        {
            Enternumber = jtxtdisplay.getText() + jbtn9.getText();
            jtxtdisplay.setText(Enternumber);
        }
    }//GEN-LAST:event_jbtn9ActionPerformed

    private void jBtnpayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnpayActionPerformed
         String Display = jtxtdisplay.getText();
         
        if(jcbopayment.getSelectedItem().equals("Select"))
        {
            JOptionPane.showMessageDialog(rootPane, "Please select a payment method", "Error", 1);
            
        }else if(jcbopayment.getSelectedItem().equals("Cash"))
        {
            
            if(Display.equals("")){
                JOptionPane.showMessageDialog(rootPane, "Please input the amount of Cash", "Error", 1);
                 
}else{
            Change();
        
        }
        }else{Change();}
    }//GEN-LAST:event_jBtnpayActionPerformed

    private void jTxtSubtotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtSubtotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTxtSubtotalActionPerformed

    private void jbtnpoint1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnpoint1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnpoint1ActionPerformed

    private void jbtn10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn10ActionPerformed

    private void jbtn11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn11ActionPerformed

    private void jbtn12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn12ActionPerformed

    private void jbtn13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn13ActionPerformed

    private void jbtn14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn14ActionPerformed

    private void jbtn15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn15ActionPerformed

    private void jbtn16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn16ActionPerformed

    private void jbtn17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn17ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn17ActionPerformed

    private void jbtn18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn18ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn18ActionPerformed

    private void jbtnc1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnc1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnc1ActionPerformed

    private void jbtn19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn19ActionPerformed

    private void jbtnpoint2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnpoint2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnpoint2ActionPerformed

    private void jbtn20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn20ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn20ActionPerformed

    private void jbtn21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn21ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn21ActionPerformed

    private void jbtn22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn22ActionPerformed

    private void jbtn23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn23ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn23ActionPerformed

    private void jbtn24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn24ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn24ActionPerformed

    private void jbtn25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn25ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn25ActionPerformed

    private void jbtn26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn26ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn26ActionPerformed

    private void jbtn27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn27ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn27ActionPerformed

    private void jbtn28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn28ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn28ActionPerformed

    private void jbtnc2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnc2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnc2ActionPerformed

    private void jbtn29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn29ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn29ActionPerformed

    private void jbtnpoint3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnpoint3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnpoint3ActionPerformed

    private void jbtn30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn30ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn30ActionPerformed

    private void jbtn31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn31ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn31ActionPerformed

    private void jbtn32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn32ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn32ActionPerformed

    private void jbtn33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn33ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn33ActionPerformed

    private void jbtn34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn34ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn34ActionPerformed

    private void jbtn35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn35ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn35ActionPerformed

    private void jbtn36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn36ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn36ActionPerformed

    private void jbtn37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn37ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn37ActionPerformed

    private void jbtn38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn38ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn38ActionPerformed

    private void jbtnc3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnc3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnc3ActionPerformed

    private void jbtn39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn39ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn39ActionPerformed

    private void jBtnCaramelFrapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnCaramelFrapActionPerformed
       int i = Integer.parseInt(t2.getText());
        ++i;
        t2.setText(String.valueOf(i));
        
        addtable("Caramel Frap        ", i, 60.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnCaramelFrapActionPerformed

    private void jBtnChocolateFrapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnChocolateFrapActionPerformed
      int i = Integer.parseInt(t1.getText());
        ++i;
        t1.setText(String.valueOf(i));
        
        addtable("Chocolate Frap    ", i, 60.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnChocolateFrapActionPerformed

    private void jBtnwhippedcoffeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnwhippedcoffeeActionPerformed
        int i = Integer.parseInt(t4.getText());
        ++i;
        t4.setText(String.valueOf(i));
        
        addtable("Whipped Coffee    ", i, 65.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnwhippedcoffeeActionPerformed

    private void jBtnblackcoffeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnblackcoffeeActionPerformed
       int i = Integer.parseInt(t3.getText());
        ++i;
        t3.setText(String.valueOf(i));
        
        addtable("Black Coffee        ", i, 35.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnblackcoffeeActionPerformed

    private void jBtncappucinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtncappucinoActionPerformed
       int i = Integer.parseInt(t6.getText());
        ++i;
        t6.setText(String.valueOf(i));
        
        addtable("Cappucino            ", i, 55.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtncappucinoActionPerformed

    private void jBtnforzencaramelfrapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnforzencaramelfrapActionPerformed
       int i = Integer.parseInt(t5.getText());
        ++i;
        t5.setText(String.valueOf(i));
        
        addtable("Frozen Caramel Frap", i, 75.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnforzencaramelfrapActionPerformed

    private void jBtnicedlattecoffeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnicedlattecoffeeActionPerformed
       int i = Integer.parseInt(t8.getText());
        ++i;
        t8.setText(String.valueOf(i));
        
        addtable("Iced Latte Coffee", i, 75.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnicedlattecoffeeActionPerformed

    private void jBtnkeemasamosaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnkeemasamosaActionPerformed
     int i = Integer.parseInt(s2.getText());
        ++i;
        s2.setText(String.valueOf(i));
        
        addtable("Keemasamos        ", i, 48.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnkeemasamosaActionPerformed

    private void jBtnquicheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnquicheActionPerformed
     int i = Integer.parseInt(s4.getText());
        ++i;
        s4.setText(String.valueOf(i));
        
        addtable("Quiche                        ", i, 50.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnquicheActionPerformed

    private void jBtncheezyfriesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtncheezyfriesActionPerformed
     int i = Integer.parseInt(s3.getText());
        ++i;
        s3.setText(String.valueOf(i));
        
        addtable("Cheezy Fries        ", i, 60.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtncheezyfriesActionPerformed

    private void jBtnpretzelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnpretzelActionPerformed
     int i = Integer.parseInt(s6.getText());
        ++i;
        s6.setText(String.valueOf(i));
        
        addtable("Pretzel                        ", i, 35.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnpretzelActionPerformed

    private void jBtnjalapenopoppersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnjalapenopoppersActionPerformed
      int i = Integer.parseInt(s5.getText());
        ++i;
        s5.setText(String.valueOf(i));
        
        addtable("Jalepeno Poppers    ", i, 60.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnjalapenopoppersActionPerformed

    private void jBtnbrushettaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnbrushettaActionPerformed
      int i = Integer.parseInt(s8.getText());
        ++i;
        s8.setText(String.valueOf(i));
        
        addtable("Brushetta            ", i, 55.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnbrushettaActionPerformed

    private void jBtngranolabarsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtngranolabarsActionPerformed
      int i = Integer.parseInt(s7.getText());
        ++i;
        s7.setText(String.valueOf(i));
        
        addtable("Granola Bars        ", i, 48.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtngranolabarsActionPerformed

    private void jBtnmozzarellasticksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnmozzarellasticksActionPerformed
     int i = Integer.parseInt(s1.getText());
        ++i;
        s1.setText(String.valueOf(i));
        
        addtable("Mozzarella Sticks", i, 55.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnmozzarellasticksActionPerformed

    private void jBtncoconutmochaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtncoconutmochaActionPerformed
       int i = Integer.parseInt(t7.getText());
        ++i;
        t7.setText(String.valueOf(i));
        
        addtable("Coconut Mocha    ", i, 60.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtncoconutmochaActionPerformed

    private void jBtnHamandEggSunriseComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnHamandEggSunriseComboActionPerformed
          int i = Integer.parseInt(q4.getText());
        ++i;
        q4.setText(String.valueOf(i));
        
        addtable("Hamand Egg Sunrise", i, 105.00);
        
        cal();
        Itemcost();
    }//GEN-LAST:event_jBtnHamandEggSunriseComboActionPerformed

    private void jBtnSunnyDogScrambleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnSunnyDogScrambleActionPerformed
        int i = Integer.parseInt(q1.getText());
        ++i;
        q1.setText(String.valueOf(i));
        
        addtable("Sunny Dog Scramble", i, 95.00);
        
        cal();
       Itemcost();
      
       
    }//GEN-LAST:event_jBtnSunnyDogScrambleActionPerformed

    private void jBtnSunriseFiestaPlatterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnSunriseFiestaPlatterActionPerformed
          int i = Integer.parseInt(q2.getText());
        ++i;
        q2.setText(String.valueOf(i));
        
        addtable("Sunrise Fiesta Platter", i, 95.00);
        
        cal();
        Itemcost();
    }//GEN-LAST:event_jBtnSunriseFiestaPlatterActionPerformed

    private void jBtnpancakeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnpancakeActionPerformed
         int i = Integer.parseInt(q8.getText());
        ++i;
        q8.setText(String.valueOf(i));
        
        addtable("Pancake                ", i, 35.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnpancakeActionPerformed

    private void jBtnsoftscrambleandsweetpotatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnsoftscrambleandsweetpotatoActionPerformed
          int i = Integer.parseInt(q5.getText());
        ++i;
        q5.setText(String.valueOf(i));
        
        addtable("Soft Scramble & Sweet Potato", i, 95.00);
        
        cal();
        Itemcost();
    }//GEN-LAST:event_jBtnsoftscrambleandsweetpotatoActionPerformed

    private void jBtnhomemademcgriddleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnhomemademcgriddleActionPerformed
          int i = Integer.parseInt(q6.getText());
        ++i;
        q6.setText(String.valueOf(i));
        
        addtable("Homemade MC Griddle", i, 45.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnhomemademcgriddleActionPerformed

    private void jBtnsweetcreamedcornActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnsweetcreamedcornActionPerformed
          int i = Integer.parseInt(q7.getText());
        ++i;
        q7.setText(String.valueOf(i));
        
        addtable("Sweet Creamed Corn", i, 40.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnsweetcreamedcornActionPerformed

    private void jBtncremebruleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtncremebruleActionPerformed
         int i = Integer.parseInt(r3.getText());
        ++i;
        r3.setText(String.valueOf(i));
        
        addtable("Creme Brule            ", i, 65.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtncremebruleActionPerformed

    private void jBtnlavacakeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnlavacakeActionPerformed
         int i = Integer.parseInt(r1.getText());
        ++i;
        r1.setText(String.valueOf(i));
        
        addtable("Lava Cake            ", i, 85.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnlavacakeActionPerformed

    private void jBtncheesecakeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtncheesecakeActionPerformed
      int i = Integer.parseInt(r2.getText());
        ++i;
        r2.setText(String.valueOf(i));
        
        addtable("Cheese Cake            ", i, 80.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtncheesecakeActionPerformed

    private void jBtnchurrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnchurrosActionPerformed
     int i = Integer.parseInt(r6.getText());
        ++i;
        r6.setText(String.valueOf(i));
        
        addtable("Churros                ", i, 45.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnchurrosActionPerformed

    private void jBtnchocolatebitssundaeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnchocolatebitssundaeActionPerformed
        int i = Integer.parseInt(r4.getText());
        ++i;
        r4.setText(String.valueOf(i));
        
        addtable("Chocolate Bits Sundae", i, 55.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnchocolatebitssundaeActionPerformed

    private void jBtnTiramisuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnTiramisuActionPerformed
      int i = Integer.parseInt(r5.getText());
        ++i;
        r5.setText(String.valueOf(i));
        
        addtable("Tiramisu                      ", i, 75.00);
        
        cal();
       Itemcost();
    }//GEN-LAST:event_jBtnTiramisuActionPerformed

    private void jBtnClassicBreakfastFusion1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnClassicBreakfastFusion1ActionPerformed
          int i = Integer.parseInt(q3.getText());
        ++i;
        q3.setText(String.valueOf(i));
        
        addtable("Classic Breakfast Fusion", i, 99.00);
        
        cal();
        Itemcost();
    }//GEN-LAST:event_jBtnClassicBreakfastFusion1ActionPerformed

    private void jtxtdisplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtdisplayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtdisplayActionPerformed

    private void jcbopaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbopaymentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jcbopaymentActionPerformed

    private void jtxtdisplayMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxtdisplayMouseClicked

    }//GEN-LAST:event_jtxtdisplayMouseClicked

    private void jTxtChangeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTxtChangeMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTxtChangeMouseClicked

    private void jTxtChangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtChangeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTxtChangeActionPerformed

    private void bAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_bAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_bAncestorAdded

    private void jbtnprint1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnprint1ActionPerformed
        // TODO add your handling code here:
         
    }//GEN-LAST:event_jbtnprint1ActionPerformed

    private void jBtnSunnyDogScramble1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnSunnyDogScramble1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jBtnSunnyDogScramble1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Java_pointofsalesproject.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Java_pointofsalesproject.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Java_pointofsalesproject.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Java_pointofsalesproject.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Java_pointofsalesproject().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea b;
    private javax.swing.JButton jBtnCaramelFrap;
    private javax.swing.JButton jBtnChocolateFrap;
    private javax.swing.JButton jBtnClassicBreakfastFusion1;
    private javax.swing.JButton jBtnHamandEggSunriseCombo;
    private javax.swing.JButton jBtnSunnyDogScramble;
    private javax.swing.JButton jBtnSunnyDogScramble1;
    private javax.swing.JButton jBtnSunriseFiestaPlatter;
    private javax.swing.JButton jBtnTiramisu;
    private javax.swing.JButton jBtnblackcoffee;
    private javax.swing.JButton jBtnbrushetta;
    private javax.swing.JButton jBtncappucino;
    private javax.swing.JButton jBtncheesecake;
    private javax.swing.JButton jBtncheezyfries;
    private javax.swing.JButton jBtnchocolatebitssundae;
    private javax.swing.JButton jBtnchurros;
    private javax.swing.JButton jBtncoconutmocha;
    private javax.swing.JButton jBtncremebrule;
    private javax.swing.JButton jBtnforzencaramelfrap;
    private javax.swing.JButton jBtngranolabars;
    private javax.swing.JButton jBtnhomemademcgriddle;
    private javax.swing.JButton jBtnicedlattecoffee;
    private javax.swing.JButton jBtnjalapenopoppers;
    private javax.swing.JButton jBtnkeemasamosa;
    private javax.swing.JButton jBtnlavacake;
    private javax.swing.JButton jBtnmozzarellasticks;
    private javax.swing.JButton jBtnpancake;
    private javax.swing.JButton jBtnpay;
    private javax.swing.JButton jBtnpretzel;
    private javax.swing.JButton jBtnquiche;
    private javax.swing.JButton jBtnsoftscrambleandsweetpotato;
    private javax.swing.JButton jBtnsweetcreamedcorn;
    private javax.swing.JButton jBtnwhippedcoffee;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTxtChange;
    private javax.swing.JTextField jTxtSubtotal;
    private javax.swing.JTextField jTxttotal;
    private javax.swing.JButton jbtn0;
    private javax.swing.JButton jbtn1;
    private javax.swing.JButton jbtn10;
    private javax.swing.JButton jbtn11;
    private javax.swing.JButton jbtn12;
    private javax.swing.JButton jbtn13;
    private javax.swing.JButton jbtn14;
    private javax.swing.JButton jbtn15;
    private javax.swing.JButton jbtn16;
    private javax.swing.JButton jbtn17;
    private javax.swing.JButton jbtn18;
    private javax.swing.JButton jbtn19;
    private javax.swing.JButton jbtn2;
    private javax.swing.JButton jbtn20;
    private javax.swing.JButton jbtn21;
    private javax.swing.JButton jbtn22;
    private javax.swing.JButton jbtn23;
    private javax.swing.JButton jbtn24;
    private javax.swing.JButton jbtn25;
    private javax.swing.JButton jbtn26;
    private javax.swing.JButton jbtn27;
    private javax.swing.JButton jbtn28;
    private javax.swing.JButton jbtn29;
    private javax.swing.JButton jbtn3;
    private javax.swing.JButton jbtn30;
    private javax.swing.JButton jbtn31;
    private javax.swing.JButton jbtn32;
    private javax.swing.JButton jbtn33;
    private javax.swing.JButton jbtn34;
    private javax.swing.JButton jbtn35;
    private javax.swing.JButton jbtn36;
    private javax.swing.JButton jbtn37;
    private javax.swing.JButton jbtn38;
    private javax.swing.JButton jbtn39;
    private javax.swing.JButton jbtn4;
    private javax.swing.JButton jbtn5;
    private javax.swing.JButton jbtn6;
    private javax.swing.JButton jbtn7;
    private javax.swing.JButton jbtn8;
    private javax.swing.JButton jbtn9;
    private javax.swing.JButton jbtnc;
    private javax.swing.JButton jbtnc1;
    private javax.swing.JButton jbtnc2;
    private javax.swing.JButton jbtnc3;
    private javax.swing.JButton jbtnexit;
    private javax.swing.JButton jbtnpay1;
    private javax.swing.JButton jbtnpoint;
    private javax.swing.JButton jbtnpoint1;
    private javax.swing.JButton jbtnpoint2;
    private javax.swing.JButton jbtnpoint3;
    private javax.swing.JButton jbtnprint;
    private javax.swing.JButton jbtnprint1;
    private javax.swing.JButton jbtnremove;
    private javax.swing.JButton jbtnreset;
    private javax.swing.JComboBox<String> jcbopayment;
    private javax.swing.JTextField jtxtdisplay;
    private javax.swing.JTextField jtxttax;
    private javax.swing.JLabel q1;
    private javax.swing.JLabel q2;
    private javax.swing.JLabel q3;
    private javax.swing.JLabel q4;
    private javax.swing.JLabel q5;
    private javax.swing.JLabel q6;
    private javax.swing.JLabel q7;
    private javax.swing.JLabel q8;
    private javax.swing.JLabel r1;
    private javax.swing.JLabel r2;
    private javax.swing.JLabel r3;
    private javax.swing.JLabel r4;
    private javax.swing.JLabel r5;
    private javax.swing.JLabel r6;
    private javax.swing.JLabel s1;
    private javax.swing.JLabel s2;
    private javax.swing.JLabel s3;
    private javax.swing.JLabel s4;
    private javax.swing.JLabel s5;
    private javax.swing.JLabel s6;
    private javax.swing.JLabel s7;
    private javax.swing.JLabel s8;
    private javax.swing.JLabel t1;
    private javax.swing.JLabel t2;
    private javax.swing.JLabel t3;
    private javax.swing.JLabel t4;
    private javax.swing.JLabel t5;
    private javax.swing.JLabel t6;
    private javax.swing.JLabel t7;
    private javax.swing.JLabel t8;
    // End of variables declaration//GEN-END:variables

    private void ItemCost() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

#include <iostream>
#include <string>
#include <vector>
using namespace std;
struct Contact {
    string name;
    string address;
    string phoneNumber;
};

void addContact(vector<Contact>& addressBook) {
    Contact contact;
    cout << "Enter name: ";
    cin.ignore();
    getline(cin, contact.name);
    cout << "Enter address: ";
    getline(cin, contact.address);
    cout << "Enter phone number: ";
    getline(cin, contact.phoneNumber);
    addressBook.push_back(contact);
    cout << "Contact added successfully!\n";
}

void displayContacts(const vector<Contact>& addressBook) {
    if (addressBook.empty()) {
        cout << "No contacts found.\n";
    } else {
        cout << "Contacts:\n";
        for (const auto& contact : addressBook) {
            cout << "Name: " << contact.name << "\n";
            cout << "Address: " << contact.address << "\n";
            cout << "Phone number: " << contact.phoneNumber << "\n\n";
        }
    }
}

void searchContact(const vector<Contact>& addressBook) {
    string searchName;
    cout << "Enter the name to search for: ";
    cin.ignore();
    getline(cin, searchName);

    bool found = false;
    for (const auto& contact : addressBook) {
        if (contact.name == searchName) {
            cout << "Contact found!\n";
            cout << "Name: " << contact.name << "\n";
            cout << "Address: " << contact.address << "\n";
            cout << "Phone number: " << contact.phoneNumber << "\n\n";
            found = true;
        }
    }

    if (!found) {
        cout << "Contact not found.\n";
    }
}

void updateContact(vector<Contact>& addressBook) {
    string searchName;
    cout << "Enter the name of the contact to update: ";
    cin.ignore();
    getline(cin, searchName);

    bool found = false;
    for (auto& contact : addressBook) {
        if (contact.name == searchName) {
            cout << "Enter new name: ";
            getline(cin, contact.name);
            cout << "Enter new address: ";
            getline(cin, contact.address);
            cout << "Enter new phone number: ";
            getline(cin, contact.phoneNumber);
            cout << "Contact updated successfully!\n";
            found = true;
        }
    }

    if (!found) {
        cout << "Contact not found.\n";
    }
}

void deleteContact(vector<Contact>& addressBook) {
    string searchName;
    cout << "Enter the name of the contact to delete: ";
    cin.ignore();
    getline(cin, searchName);

    bool found = false;
    for (auto it = addressBook.begin(); it != addressBook.end(); ++it) {
        if (it->name == searchName) {
            addressBook.erase(it);
            cout << "Contact deleted successfully!\n";
            found = true;
            break;
        }
    }

    if (!found) {
        cout <<"Contact not found.\n";
}
}


int main() {
vector<Contact> addressBook;
int choice;

while (true) {
    cout << "Address Book\n";
    cout << "1. Add Contact\n";
    cout << "2. Display Contacts\n";
    cout << "3. Search Contact\n";
    cout << "4. Update Contact\n";
    cout << "5. Delete Contact\n";
    cout << "6. Quit\n";
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice) {
        case 1:
            addContact(addressBook);
            break;
        case 2:
            displayContacts(addressBook);
            break;
        case 3:
            searchContact(addressBook);
            break;
        case 4:
            updateContact(addressBook);
            break;
        case 5:
            deleteContact(addressBook);
            break;
        case 6:
            cout << "Quitting the program. Goodbye!\n";
            return 0;
        default:
            cout << "Invalid choice. Please try again.\n";
            break;
    }
}

return 0;

}